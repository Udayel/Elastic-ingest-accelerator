import os
import yaml
import boto3
import json
import base64
import cfnresponse

def lambda_handler(event, context):

    # Log the event details for debugging
    print("Received event: " + json.dumps(event, indent=2))

    # Extract properties from the CloudFormation event
    properties = event.get('ResourceProperties', {})

    try:
        # Access StackId from the event
        stack_id = event['StackId']
        # Fetch SQS queue ARN from environment variable
        sqs_queue_arns = os.environ.get('SQS_QUEUE_ARN')

        # Fetch S3 bucket name from environment variable
        s3_bucket_name = os.environ.get('S3_BUCKET_NAME')

        # Get environment variables
        cloudtrail_s3_bucket_name = os.environ['CloudTrail_S3_BUCKET_NAME']
        cloudtrail_sqs_queue_arn = os.environ['CloudTrail_SQS_QUEUE_ARN']

        # Fetch CloudWatch Log Group ARNs from environment variable
        cloudwatch_log_group_arns = os.environ.get('CLOUDWATCH_LOG_GROUP_ARNS')

        # Fetch Kinesis data stream ARNs from environment variable
        kinesis_data_stream_arns = os.environ.get('KINESIS_DATA_STREAM_ARNS')

        # Fetch whether to ingest CloudWatch logs
        ingest_cloudwatch_logs = os.environ.get('INGEST_CLOUDWATCH_LOGS')

        # Fetch whether to ingest Kinesis Data Stream
        ingest_kinesis_logs = os.environ.get('INGEST_KINESIS_LOGS')

        # Fetch Kinesis Data Stream ARNs only if ingestion is enabled
        kinesis_data_stream_arns = (
            os.environ.get('KINESIS_DATA_STREAM_ARNS').split(',')
            if ingest_kinesis_logs.lower() == "yes"
            else []
        )

        # Fetch CloudWatch Log Group ARNs only if ingestion is enabled
        cloudwatch_log_group_arns = (
            os.environ.get('CLOUDWATCH_LOG_GROUP_ARNS').split(',')
            if ingest_cloudwatch_logs.lower() == "yes"
            else []
        )

        # Create an S3 client
        s3_client = boto3.client('s3')
 
        # Define the S3 event notification configuration
        s3_event_config = {
            'QueueConfigurations': [
                {
                    'Events': ['s3:ObjectCreated:*'],
                    'QueueArn': cloudtrail_sqs_queue_arn,
                    'Filter': {
                        'Key': {
                            'FilterRules': [
                                {
                                    'Name': 'prefix',
                                    'Value': ''  # You can specify a prefix if needed
                                }
                            ]
                        }
                    }
                }
            ]
        }
 
        # Put the S3 event configuration on the S3 bucket
        s3_client.put_bucket_notification_configuration(
            Bucket=cloudtrail_s3_bucket_name,
            NotificationConfiguration=s3_event_config
        )

        # Check if required environment variables are set
        if not sqs_queue_arns or not s3_bucket_name:
            return {
                'statusCode': 500,
                'body': 'Missing required environment variables.'
            }

        # Split the comma-separated string of SQS queue ARNs into a list
        sqs_queue_arns = [arn.strip() for arn in sqs_queue_arns.split(',')]

        # Fetch Secrets Manager ARN from environment variable
        elastic_secret_arn = os.environ.get('ELASTIC_SECRET_ARN')

        # Generate config.yml content dynamically
        config_content = ""
        for arn in sqs_queue_arns:
            config_content += f"""  - type: "s3-sqs"
    id: "{arn}"
    outputs:
    - type: "elasticsearch"
      args:
        cloud_id: "{elastic_secret_arn}:ElasticCloudID"
        api_key: "{elastic_secret_arn}:APIKey"
"""
            
        if ingest_kinesis_logs.lower() == "yes":
            for arn in kinesis_data_stream_arns:
                config_content += f"""  - type: "kinesis-data-stream"
    id: "{arn}"
    outputs:
      - type: "elasticsearch"
        args:
          cloud_id: "{elastic_secret_arn}:ElasticCloudID"
          api_key: "{elastic_secret_arn}:APIKey"
          es_datastream_name: "logs-generic-default"
"""
            
        # Add CloudWatch Log Groups to the configuration if requested
        if ingest_cloudwatch_logs.lower() == "yes":
            for arn in cloudwatch_log_group_arns:
                config_content += f"""  - type: "cloudwatch-logs"
    id: "{arn}"
    outputs:
      - type: "elasticsearch"
        args:
          cloud_id: "{elastic_secret_arn}:ElasticCloudID"
          api_key: "{elastic_secret_arn}:APIKey"
          es_datastream_name: "logs-generic-default"
"""

        # Create the final YAML content with the required structure
        final_config_content = f"""inputs:
{config_content}"""

        # Convert YAML to bytes
        config_bytes = final_config_content.encode('utf-8')

        # Upload config.yml to S3
        s3_client = boto3.client('s3')
        s3_client.put_object(Bucket=s3_bucket_name, Key='config.yml', Body=config_bytes)

        # Define responseData
        responseData = {'Message': 'Configuration uploaded successfully.'}

        # Send a success or failure response back to CloudFormation
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)

    except Exception as e:
        # Handle exceptions and send a failure response
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})