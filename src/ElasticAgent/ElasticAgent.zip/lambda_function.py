import boto3
import os
import botocore
import json
import uuid
import random
import string
import requests
import cfnresponse

def lambda_handler(event, context):
                
    responseData = {}                
    # Generate a random suffix adhering to the CloudFormation stack name pattern
    random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    
    # Combine the suffix with a prefix adhering to the pattern (e.g., "Elastic-Agent-")
    stack_name = 'Elastic-Agent-' + random_suffix
                
    # GitHub repository information
    github_raw_url = 'https://raw.githubusercontent.com/Udayel/Elastic-ingest-accelerator/main/src/ElasticAgent/elastic-agent-ec2-metrics.json'
    
    # Fetch the CloudFormation Template from GitHub
    try:
        response = requests.get(github_raw_url)
        template_body = response.text
        
    except Exception as e:
        print(f"Error fetching template from GitHub: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error fetching template from GitHub')
        }

    # Extract parameters from the Lambda input
    kibana_url = os.getenv('KibanaURL')
    elasticsearch_username = os.getenv('ELASTICSEARCHUSERNAME')
    elasticsearch_password = os.getenv('ELASTICSEARCHPASSWORD')
    elasticsearch_deploymentid = os.getenv('ElasticSearchDeploymentID')
    elasticsearch_deploymentversion = os.getenv('DeploymentVersion')
    region = os.getenv('REGION')
    ami_id = os.getenv('AMIID')
    agent_subnet = os.getenv('ElasticEC2AgentSubnet')
    agent_vpc = os.getenv('ElasticEC2AgentVPC')
    tag_key1 = os.getenv('TagKeyName1')
    tag_value1 = os.getenv('TagValueName1')
    tag_key2 = os.getenv('TagKeyName2')
    tag_value2 = os.getenv('TagValueName2')
    tag_key3 = os.getenv('TagKeyName3')
    tag_value3 = os.getenv('TagValueName3')
    tag_key4 = os.getenv('TagKeyName4')
    tag_value4 = os.getenv('TagValueName4')
    tag_key5 = os.getenv('TagKeyName5')
    tag_value5 = os.getenv('TagValueName5')
    tag_key6 = os.getenv('TagKeyName6')
    tag_value6 = os.getenv('TagValueName6')

    cloudformation_client = boto3.client('cloudformation', region_name=region)
    
                
    # Deploy the CloudFormation Template
    try:
        response = cloudformation_client.create_stack(
            StackName=stack_name,
            TemplateBody=template_body,
            Parameters=[
                {'ParameterKey': 'ElasticEC2AgentSubnet', 'ParameterValue': agent_subnet},
                {'ParameterKey': 'ElasticEC2AgentVPC', 'ParameterValue': agent_vpc},
                {'ParameterKey': 'KibanaURL', 'ParameterValue': kibana_url},
                {'ParameterKey': 'AMIID', 'ParameterValue': ami_id},
                {'ParameterKey': 'ELASTICSEARCHUSERNAME', 'ParameterValue': elasticsearch_username},
                {'ParameterKey': 'ELASTICSEARCHPASSWORD', 'ParameterValue': elasticsearch_password},
                {'ParameterKey': 'ElasticSearchDeploymentID', 'ParameterValue': elasticsearch_deploymentid},
                {'ParameterKey': 'DeploymentVersion', 'ParameterValue': elasticsearch_deploymentversion},
                {'ParameterKey': 'TagKeyName1', 'ParameterValue': tag_key1},
                {'ParameterKey': 'TagValueName1', 'ParameterValue': tag_value1},
                {'ParameterKey': 'TagKeyName2', 'ParameterValue': tag_key2},
                {'ParameterKey': 'TagValueName2', 'ParameterValue': tag_value2},
                {'ParameterKey': 'TagKeyName3', 'ParameterValue': tag_key3},
                {'ParameterKey': 'TagValueName3', 'ParameterValue': tag_value3},
                {'ParameterKey': 'TagKeyName4', 'ParameterValue': tag_key4},
                {'ParameterKey': 'TagValueName4', 'ParameterValue': tag_value4},
                {'ParameterKey': 'TagKeyName5', 'ParameterValue': tag_key5},
                {'ParameterKey': 'TagValueName5', 'ParameterValue': tag_value5},
                {'ParameterKey': 'TagKeyName6', 'ParameterValue': tag_key6},
                {'ParameterKey': 'TagValueName6', 'ParameterValue': tag_value6},
            ],
            Capabilities=['CAPABILITY_NAMED_IAM']  # Add capabilities if needed
        )
        print(f"Stack {stack_name} creation initiated. Stack ID: {response['StackId']}")
    except botocore.exceptions.ClientError as e:
        print(f"Error deploying CloudFormation Template: {e}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})

    print("CloudFormation Template deployed successfully.")
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    