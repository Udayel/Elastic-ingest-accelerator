import boto3
import os
import botocore
import json
import uuid
import random
import string
import requests
import cfnresponse

def lambda_handler(event, context):
                
    responseData = {}                
    # Generate a random suffix adhering to the CloudFormation stack name pattern
    random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    
    # Combine the suffix with a prefix adhering to the pattern (e.g., "Elastic-Agent-")
    stack_name = 'Elastic-Agent-' + random_suffix
                
    # GitHub repository information
    github_raw_url = 'https://raw.githubusercontent.com/Udayel/Elastic-ingest-accelerator/main/Elastic-cloud-reverse-proxy-integration/elastic-reverse-proxy.json'
    
    # Fetch the CloudFormation Template from GitHub
    try:
        response = requests.get(github_raw_url)
        template_body = response.text
        
    except Exception as e:
        print(f"Error fetching template from GitHub: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error fetching template from GitHub')
        }

    # Extract parameters from the Lambda input
    region = os.getenv('REGION')
    ami_id = os.getenv('AMIID')
    agent_subnet = os.getenv('ElasticSubnet')
    agent_vpc = os.getenv('ElasticVPC')
    kibana_custom_domain_url = os.getenv('KibanaCustomDomainURL')
    elasticsearch_username = os.getenv('UserName') if os.getenv('AnonymousAccess') == 'Yes' else ''
    elasticsearch_password = os.getenv('Password') if os.getenv('AnonymousAccess') == 'Yes' else ''
    elastic_custom_domain_url = os.getenv('ElasticCustomDomainURL')
    elastic_endpoint = os.getenv('ElasticEndpoint')
    elastic_cluster_id = os.getenv('ElasticClusterID')
    kibana_endpoint = os.getenv('KibanaEndpoint')
    kibana_component_id = os.getenv('KibanaComponentID')
    anonymous_access = os.getenv('AnonymousAccess')
    dashboard_preloggedin_custom_domain_url = os.getenv('DashboardPreloggedInCustomDomainURL')
    

    cloudformation_client = boto3.client('cloudformation', region_name=region)
    
                
    # Deploy the CloudFormation Template
    try:
        response = cloudformation_client.create_stack(
            StackName=stack_name,
            TemplateBody=template_body,
            Parameters=[
                {'ParameterKey': 'ElasticSubnet', 'ParameterValue': agent_subnet},
                {'ParameterKey': 'ElasticVPC', 'ParameterValue': agent_vpc},
                {'ParameterKey': 'KibanaCustomURL', 'ParameterValue': kibana_custom_domain_url},
                {'ParameterKey': 'UserName', 'ParameterValue': elasticsearch_username},
                {'ParameterKey': 'Password', 'ParameterValue': elasticsearch_password},
                {'ParameterKey': 'ElasticCustomURL', 'ParameterValue': elastic_custom_domain_url},
                {'ParameterKey': 'ElasticEndpoint', 'ParameterValue': elastic_endpoint},
                {'ParameterKey': 'ElasticClusterID', 'ParameterValue': elastic_cluster_id},
                {'ParameterKey': 'KibanaEndpoint', 'ParameterValue': kibana_endpoint},
                {'ParameterKey': 'KibanaComponentID', 'ParameterValue': kibana_component_id},
                {'ParameterKey': 'AnonymousAccess', 'ParameterValue': anonymous_access},
                {'ParameterKey': 'DashboardPreloggedInCustomDomainURL', 'ParameterValue': dashboard_preloggedin_custom_domain_url},
                {'ParameterKey': 'AMIID', 'ParameterValue': ami_id},    
            ],
            Capabilities=['CAPABILITY_NAMED_IAM']  # Add capabilities if needed
        )
        print(f"Stack {stack_name} creation initiated. Stack ID: {response['StackId']}")
    except botocore.exceptions.ClientError as e:
        print(f"Error deploying CloudFormation Template: {e}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})

    print("CloudFormation Template deployed successfully.")
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    